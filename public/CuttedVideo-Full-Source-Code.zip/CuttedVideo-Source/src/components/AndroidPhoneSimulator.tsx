import React, { useState, useRef, useEffect } from 'react';
import {
  Film,
  Scissors,
  Gauge,
  Sliders,
  Sparkles,
  Play,
  Pause,
  Upload,
  ArrowLeft,
  Volume2,
  VolumeX,
  Layers,
  Clock,
  HardDrive,
  Sun,
  Moon,
  Monitor,
  CheckCircle2,
  ChevronRight,
  Maximize2,
  RotateCcw,
} from 'lucide-react';
import {
  OutputResolution,
  VideoMetadata,
  SplitProfile,
  SegmentInfo,
  ExportProgressState,
  ThemeMode,
  CutPreset,
  AppPreferences,
} from '../types';
import {
  calculateSegments,
  calculateTargetDimensions,
  formatBytes,
  formatDuration,
  processSingleSegment,
  extractVideoMetadata,
} from '../utils/videoProcessor';
import { generateSampleVideo } from '../utils/sampleVideos';
import { AppLogo } from './AppLogo';
import { SpeedBottomSheet } from './SpeedBottomSheet';
import { QualityBottomSheet } from './QualityBottomSheet';
import { CutsBottomSheet } from './CutsBottomSheet';
import { ProcessingProgressSheet } from './ProcessingProgressSheet';
import { ResultSummaryModal } from './ResultSummaryModal';

const PREFS_STORAGE_KEY = 'cuttedvideo_user_config_v2';

const DEFAULT_PREFS: AppPreferences = {
  theme: 'auto',
  speed: 1.0,
  muteAudio: false,
  quality: 'original',
  customHeight: 720,
  cutPreset: '30s',
  customCutSeconds: 45,
};

function loadStoredPreferences(): AppPreferences {
  try {
    const raw = localStorage.getItem(PREFS_STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_PREFS, ...JSON.parse(raw) };
    }
  } catch {
    // fallback
  }
  return DEFAULT_PREFS;
}

function saveStoredPreferences(prefs: AppPreferences) {
  try {
    localStorage.setItem(PREFS_STORAGE_KEY, JSON.stringify(prefs));
  } catch {
    // ignore
  }
}

interface AndroidPhoneSimulatorProps {
  profiles?: SplitProfile[];
  onSaveProfile?: (profile: SplitProfile) => void;
  onDeleteProfile?: (id: string) => void;
  onResetProfiles?: () => void;
}

export const AndroidPhoneSimulator: React.FC<AndroidPhoneSimulatorProps> = () => {
  // 1. Initial State from Persistence
  const [prefs, setPrefs] = useState<AppPreferences>(loadStoredPreferences);

  // Sync state helpers
  const { theme, speed, muteAudio, quality, customHeight, cutPreset, customCutSeconds } = prefs;

  const updatePref = <K extends keyof AppPreferences>(key: K, value: AppPreferences[K]) => {
    setPrefs((prev) => {
      const next = { ...prev, [key]: value };
      saveStoredPreferences(next);
      return next;
    });
  };

  // 2. System Theme Detection (Auto / Light / Dark)
  const [systemIsDark, setSystemIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return true;
  });

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemIsDark(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  const isDark = theme === 'dark' || (theme === 'auto' && systemIsDark);

  // 3. Screen State ('upload' | 'editor')
  const [screen, setScreen] = useState<'upload' | 'editor'>('upload');
  const [selectedVideo, setSelectedVideo] = useState<VideoMetadata | null>(null);
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  // 4. Video Player State
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [videoCurrentTime, setVideoCurrentTime] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);
  const [isPreviewMuted, setIsPreviewMuted] = useState(false);

  // 5. Active Bottom Sheet Modal ('speed' | 'quality' | 'cuts' | null)
  const [activeSheet, setActiveSheet] = useState<'speed' | 'quality' | 'cuts' | null>(null);

  // 6. Export & Progress State
  const [exportState, setExportState] = useState<ExportProgressState>({
    isExporting: false,
    currentSegmentIndex: 0,
    totalSegments: 0,
    overallPercent: 0,
    currentSegmentPercent: 0,
    segments: [],
    isCancelled: false,
    isCompleted: false,
    elapsedTimeSeconds: 0,
  });
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Hidden File Input
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 7. Math calculations for cuts and duration
  const effectiveCutSeconds =
    cutPreset === '30s'
      ? 30
      : cutPreset === '60s'
      ? 60
      : cutPreset === '90s'
      ? 90
      : Math.max(5, customCutSeconds);

  const { estimatedTotalDuration, segments } = selectedVideo
    ? calculateSegments(selectedVideo.duration, speed, effectiveCutSeconds, selectedVideo.name)
    : { estimatedTotalDuration: 0, segments: [] };

  const targetDims = selectedVideo
    ? calculateTargetDimensions(selectedVideo.width, selectedVideo.height, quality, customHeight)
    : { width: 1080, height: 1920 };

  // 8. Video Player Controls
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setVideoCurrentTime(time);
    }
  };

  // Sync playback rate and mute with video element
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
      videoRef.current.preservesPitch = true;
    }
  }, [speed]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isPreviewMuted || muteAudio;
    }
  }, [isPreviewMuted, muteAudio]);

  // 9. Video Upload Handler
  const handleSelectVideoFile = async (file: File) => {
    try {
      const meta = await extractVideoMetadata(file);
      setSelectedVideo(meta);
      setVideoDuration(meta.duration);
      setVideoCurrentTime(0);
      setIsPlaying(false);
      updatePref('speed', 1.0); // Restablecer a 1.0x para no comprimir clips inesperadamente
      setScreen('editor');
    } catch (err) {
      console.error(err);
      alert('Error cargando el video: ' + (err as Error).message);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleSelectVideoFile(e.target.files[0]);
    }
  };

  const handleQuickSample = async () => {
    try {
      setIsGeneratingSample(true);
      const sampleFile = await generateSampleVideo(105, 'video_demo_cuttedvideo');
      setIsGeneratingSample(false);
      handleSelectVideoFile(sampleFile);
    } catch (err) {
      setIsGeneratingSample(false);
      console.error(err);
      alert('Error creando video de muestra: ' + (err as Error).message);
    }
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(true);
  };
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
  };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleSelectVideoFile(e.dataTransfer.files[0]);
    }
  };

  // 10. Process & Export Handler
  const handleStartExport = async () => {
    if (!selectedVideo || segments.length === 0) return;

    // Pause preview before processing
    if (videoRef.current) {
      videoRef.current.pause();
      setIsPlaying(false);
    }

    abortControllerRef.current = new AbortController();
    const signal = abortControllerRef.current.signal;

    const initialSegments: SegmentInfo[] = segments.map((s) => ({
      ...s,
      status: 'pending',
      progress: 0,
    }));

    setExportState({
      isExporting: true,
      currentSegmentIndex: 1,
      totalSegments: segments.length,
      overallPercent: 0,
      currentSegmentPercent: 0,
      segments: initialSegments,
      isCancelled: false,
      isCompleted: false,
      elapsedTimeSeconds: 0,
    });

    for (let i = 0; i < initialSegments.length; i++) {
      if (signal.aborted) {
        setExportState((prev) => ({ ...prev, isExporting: false, isCancelled: true }));
        return;
      }

      const currentSeg = initialSegments[i];

      setExportState((prev) => {
        const updated = [...prev.segments];
        updated[i] = { ...updated[i], status: 'processing', progress: 0 };
        return {
          ...prev,
          currentSegmentIndex: i + 1,
          currentSegmentPercent: 0,
          segments: updated,
        };
      });

      try {
        const { blob, url, size } = await processSingleSegment(
          selectedVideo.fileUrl,
          currentSeg,
          speed,
          targetDims.width,
          targetDims.height,
          signal,
          (segPercent) => {
            setExportState((prev) => {
              const segFraction = 1 / initialSegments.length;
              const overall = Math.min(
                100,
                Math.round((i * segFraction + (segPercent / 100) * segFraction) * 100)
              );
              return {
                ...prev,
                currentSegmentPercent: segPercent,
                overallPercent: overall,
              };
            });
          },
          muteAudio
        );

        const doneSegment: SegmentInfo = {
          ...currentSeg,
          status: 'completed',
          progress: 100,
          blob,
          blobUrl: url,
          fileSizeBytes: size,
        };

        setExportState((prev) => {
          const updated = [...prev.segments];
          updated[i] = doneSegment;
          return {
            ...prev,
            segments: updated,
            overallPercent: Math.round(((i + 1) / initialSegments.length) * 100),
          };
        });
      } catch (err: unknown) {
        if ((err as Error).name === 'AbortError' || signal.aborted) {
          setExportState((prev) => ({ ...prev, isExporting: false, isCancelled: true }));
          return;
        }

        setExportState((prev) => ({
          ...prev,
          isExporting: false,
          error: `Error procesando clip ${i + 1}: ${(err as Error).message}`,
        }));
        return;
      }
    }

    setExportState((prev) => ({
      ...prev,
      isExporting: false,
      isCompleted: true,
      overallPercent: 100,
    }));

    setIsSummaryOpen(true);
  };

  const handleCancelExport = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setExportState((prev) => ({
      ...prev,
      isExporting: false,
      isCancelled: true,
    }));
  };

  // Color Styles based on isDark
  const themeContainer = isDark
    ? 'bg-slate-950 text-slate-100 border-slate-800'
    : 'bg-slate-50 text-slate-900 border-slate-200';
  const themeCard = isDark
    ? 'bg-slate-900/90 border-slate-800 text-slate-100'
    : 'bg-white border-slate-200/90 text-slate-900 shadow-sm';
  const themeSubtle = isDark
    ? 'bg-slate-900/60 border-slate-800 text-slate-400'
    : 'bg-slate-100/80 border-slate-200 text-slate-600';
  const themeTextMuted = isDark ? 'text-slate-400' : 'text-slate-500';

  return (
    <div
      className={`relative mx-auto w-full max-w-[430px] aspect-[9/19.5] sm:h-[840px] rounded-[50px] border-[10px] ${
        isDark ? 'border-slate-800 ring-1 ring-slate-700/60' : 'border-slate-300 ring-1 ring-slate-200'
      } shadow-2xl overflow-hidden flex flex-col select-none transition-colors duration-300 ${themeContainer}`}
    >
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        onChange={handleFileInputChange}
        className="hidden"
      />

      {/* Dynamic Island / Front Camera */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-50 flex items-center justify-center pointer-events-none">
        <div className="w-20 h-4 rounded-full bg-black flex items-center justify-between px-2.5">
          <div className="w-2 h-2 rounded-full bg-slate-900 ring-1 ring-slate-800" />
          <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />
        </div>
      </div>

      {/* Android Status Bar */}
      <div
        className={`pt-3 px-7 pb-1 text-[11px] font-medium flex items-center justify-between z-40 tracking-tight transition-colors ${
          isDark ? 'bg-slate-950/80 text-slate-400' : 'bg-slate-100/90 text-slate-600'
        }`}
      >
        <span>10:30</span>
        <div className="flex items-center gap-1.5 text-[10px]">
          <span>5G</span>
          <span>98%</span>
        </div>
      </div>

      {/* ========================================================
          PANTALLA 1: PANTALLA PRINCIPAL (BIENVENIDA & SUBIR VIDEO)
          ======================================================== */}
      {screen === 'upload' && (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className="flex-1 flex flex-col justify-between p-5 overflow-hidden animate-in fade-in duration-300 relative"
        >
          {/* Top Bar with Logo and Theme Mode Switcher (Auto, Claro, Oscuro) */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-2">
              <AppLogo size="sm" />
              <span className="font-extrabold text-sm tracking-tight">CuttedVideo</span>
            </div>

            {/* Selector superior derecho: "Auto", "Claro", "Oscuro" con iconos */}
            <div
              className={`p-1 rounded-xl border flex items-center text-[10px] font-bold transition ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              {(
                [
                  { id: 'auto', label: 'Auto', icon: Monitor },
                  { id: 'light', label: 'Claro', icon: Sun },
                  { id: 'dark', label: 'Oscuro', icon: Moon },
                ] as const
              ).map((m) => {
                const isActive = theme === m.id;
                const IconComp = m.icon;
                return (
                  <button
                    key={m.id}
                    onClick={() => updatePref('theme', m.id)}
                    className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : isDark
                        ? 'text-slate-400 hover:text-slate-200'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <IconComp className="w-3 h-3" />
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Hero & App Icon */}
          <div className="flex flex-col items-center text-center my-auto space-y-4">
            <AppLogo size="xl" showBadge />

            <div className="space-y-1">
              <h1 className="text-xl font-black tracking-tight">
                Corta tus Videos al Segundo
              </h1>
              <p className={`text-xs max-w-[260px] mx-auto ${themeTextMuted}`}>
                Divide clips perfectos para WhatsApp, Instagram Reels y TikTok sin perder calidad.
              </p>
            </div>

            {/* Clear Concise Instructions */}
            <div
              className={`w-full max-w-[320px] rounded-2xl border p-3.5 text-left text-xs space-y-2 ${themeCard}`}
            >
              <div className="flex items-center gap-2.5">
                <span className="w-5 h-5 rounded-full bg-indigo-500/15 text-indigo-500 flex items-center justify-center font-bold text-[11px]">
                  1
                </span>
                <span className="text-xs">Sube tu video (MP4, MOV o WebM)</span>
              </div>
              <div className="flex items-center gap-2.5">
                <span className="w-5 h-5 rounded-full bg-indigo-500/15 text-indigo-500 flex items-center justify-center font-bold text-[11px]">
                  2
                </span>
                <span className="text-xs">Ajusta velocidad, calidad y duración</span>
              </div>
              <div className="flex items-center gap-2.5">
                <span className="w-5 h-5 rounded-full bg-indigo-500/15 text-indigo-500 flex items-center justify-center font-bold text-[11px]">
                  3
                </span>
                <span className="text-xs">Exporta o comparte en orden exacto</span>
              </div>
            </div>
          </div>

          {/* Bottom Actions: Upload Button & Quick Sample Demo */}
          <div className="space-y-2.5 pb-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className={`w-full py-3.5 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-2.5 shadow-xl transition-all duration-200 active:scale-[0.98] ${
                isDraggingFile
                  ? 'bg-emerald-600 text-white ring-4 ring-emerald-500/30'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
              }`}
            >
              <Upload className="w-4 h-4" />
              <span>{isDraggingFile ? '¡Suelta tu video aquí!' : 'Subir Archivo de Video'}</span>
            </button>

            <button
              onClick={handleQuickSample}
              disabled={isGeneratingSample}
              className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold border flex items-center justify-center gap-2 transition active:scale-[0.99] ${
                isDark
                  ? 'border-slate-800 text-slate-300 hover:bg-slate-900 hover:border-slate-700'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span>
                {isGeneratingSample ? 'Creando demo...' : 'O probar con video de muestra rápido'}
              </span>
            </button>

            {/* Android Navigation Bar Pill */}
            <div className="pt-2">
              <div className="w-28 h-1 bg-slate-500/30 rounded-full mx-auto" />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          PANTALLA 2: PANTALLA DE EDICIÓN & CORTES (VIDEO + MENÚ INFERIOR)
          ======================================================== */}
      {screen === 'editor' && selectedVideo && (
        <div className="flex-1 flex flex-col justify-between overflow-hidden relative animate-in fade-in duration-300">
          {/* Top Bar: Botón 'Cambiar Video' a la izquierda y 'Cortar y Procesar' a la derecha */}
          <div
            className={`px-3.5 py-2.5 border-b flex items-center justify-between z-30 ${
              isDark ? 'bg-slate-950/95 border-slate-800/80' : 'bg-white/95 border-slate-200 shadow-sm'
            }`}
          >
            {/* Botón con icono "Cambiar Video" para salir y elegir otro archivo */}
            <button
              onClick={() => {
                if (videoRef.current) videoRef.current.pause();
                setIsPlaying(false);
                setScreen('upload');
              }}
              className={`flex items-center gap-1.5 text-xs font-bold transition px-3 py-1.5 rounded-xl border active:scale-95 shadow-sm ${
                isDark
                  ? 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800 hover:text-white'
                  : 'bg-slate-100 border-slate-200 text-slate-800 hover:bg-slate-200'
              }`}
              title="Volver a la pantalla principal para elegir otro video"
            >
              <RotateCcw className="w-3.5 h-3.5 text-indigo-500" />
              <span>Cambiar Video</span>
            </button>

            {/* Botón superior derecho: "Cortar y Procesar" */}
            <button
              onClick={handleStartExport}
              disabled={exportState.isExporting}
              className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white font-extrabold text-[11px] flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition active:scale-95"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Cortar y Procesar</span>
            </button>
          </div>

          {/* Main Top Section: Video Player with Full Controls (Always Visible) */}
          <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-start overflow-hidden">
            {/* Video Container */}
            <div
              className={`relative w-full aspect-video bg-black rounded-2xl overflow-hidden border shadow-lg flex items-center justify-center group ${
                isDark ? 'border-slate-800' : 'border-slate-300'
              }`}
            >
              <video
                ref={videoRef}
                src={selectedVideo.fileUrl}
                playsInline
                loop
                onTimeUpdate={() => {
                  if (videoRef.current) {
                    setVideoCurrentTime(videoRef.current.currentTime);
                  }
                }}
                onEnded={() => setIsPlaying(false)}
                className="w-full h-full object-contain"
              />

              {/* Center Play/Pause button overlay */}
              <button
                onClick={togglePlay}
                className={`absolute inset-0 flex items-center justify-center bg-black/25 transition-opacity ${
                  isPlaying ? 'opacity-0 group-hover:opacity-100' : 'opacity-100'
                }`}
              >
                <div className="w-12 h-12 rounded-full bg-slate-950/80 backdrop-blur border border-white/20 text-white flex items-center justify-center shadow-xl hover:scale-110 transition">
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                </div>
              </button>

              {/* Bottom Scrubber Overlay */}
              <div className="absolute bottom-0 inset-x-0 p-2 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col gap-1 z-10">
                <input
                  type="range"
                  min="0"
                  max={videoDuration || 1}
                  step="0.1"
                  value={videoCurrentTime}
                  onChange={handleSeek}
                  className="w-full h-1 accent-indigo-500 cursor-pointer bg-white/20 rounded-lg"
                />

                <div className="flex items-center justify-between text-[10px] text-white/90 font-mono">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={togglePlay}
                      className="p-0.5 hover:text-indigo-400 transition"
                    >
                      {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                    </button>
                    <span>{formatDuration(videoCurrentTime)}</span>
                    <span className="text-white/40">/</span>
                    <span>{formatDuration(videoDuration)}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[9px] bg-white/10 px-1.5 py-0.2 rounded font-mono">
                      {speed}x
                    </span>
                    <button
                      onClick={() => setIsPreviewMuted(!isPreviewMuted)}
                      className="p-0.5 hover:text-indigo-400 transition"
                    >
                      {isPreviewMuted || muteAudio ? (
                        <VolumeX className="w-3.5 h-3.5 text-amber-400" />
                      ) : (
                        <Volume2 className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Video Metadata Pills */}
            <div className="grid grid-cols-4 gap-1.5 text-center">
              <div className={`p-1.5 rounded-xl border ${themeCard}`}>
                <span className={`text-[9px] block ${themeTextMuted}`}>Duración</span>
                <span className="text-[11px] font-bold font-mono">
                  {selectedVideo.duration.toFixed(1)}s
                </span>
              </div>
              <div className={`p-1.5 rounded-xl border ${themeCard}`}>
                <span className={`text-[9px] block ${themeTextMuted}`}>Resolución</span>
                <span className="text-[11px] font-bold font-mono">
                  {selectedVideo.width}×{selectedVideo.height}
                </span>
              </div>
              <div className={`p-1.5 rounded-xl border ${themeCard}`}>
                <span className={`text-[9px] block ${themeTextMuted}`}>Tamaño</span>
                <span className="text-[11px] font-bold font-mono">
                  {formatBytes(selectedVideo.size)}
                </span>
              </div>
              <div className={`p-1.5 rounded-xl border ${themeCard}`}>
                <span className={`text-[9px] block ${themeTextMuted}`}>Clips</span>
                <span className="text-[11px] font-black font-mono text-emerald-500">
                  {segments.length}
                </span>
              </div>
            </div>

            {/* Timeline Visual & Summary Cards */}
            <div className={`p-2.5 rounded-2xl border space-y-1.5 ${themeCard}`}>
              <div className="flex items-center justify-between text-[11px] font-semibold">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Esquema de Clips ({segments.length} partes)</span>
                </span>
                <span className={`text-[10px] font-mono ${themeTextMuted}`}>
                  {effectiveCutSeconds}s máx
                </span>
              </div>

              {/* Segment Slices Bar */}
              <div className="flex h-5 w-full rounded-lg overflow-hidden bg-slate-900 border border-slate-800 gap-0.5 p-0.5">
                {segments.map((seg) => {
                  const widthPercent =
                    estimatedTotalDuration > 0
                      ? (seg.outputDuration / estimatedTotalDuration) * 100
                      : 100 / segments.length;
                  return (
                    <div
                      key={seg.index}
                      className="h-full bg-gradient-to-r from-indigo-500 to-sky-400 rounded-[3px] flex items-center justify-center text-[9px] font-mono text-white font-bold truncate px-0.5 shadow-sm"
                      style={{ width: `${Math.max(5, widthPercent)}%` }}
                      title={`Clip ${seg.index}: ${seg.outputDuration.toFixed(1)}s`}
                    >
                      #{seg.index} ({seg.outputDuration.toFixed(0)}s)
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-[10px] font-medium pt-0.5">
                <span className={themeTextMuted}>
                  Duración final: <b className="text-indigo-500">{estimatedTotalDuration.toFixed(1)}s</b>
                </span>
                <span className={themeTextMuted}>
                  Salida: <b className="text-sky-500">{targetDims.width}×{targetDims.height}</b>
                </span>
              </div>
            </div>
          </div>

          {/* Menú inferior con iconos: 1. Velocidad, 2. Calidad, 3. Cortes */}
          <div
            className={`border-t px-4 pt-2.5 pb-2 z-30 transition-colors ${
              isDark ? 'bg-slate-950/95 border-slate-800' : 'bg-white border-slate-200 shadow-lg'
            }`}
          >
            <div className="grid grid-cols-3 gap-2">
              {/* 1. Velocidad */}
              <button
                onClick={() => setActiveSheet('speed')}
                className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition active:scale-95 ${
                  activeSheet === 'speed'
                    ? 'border-indigo-500 bg-indigo-500/15 text-indigo-500'
                    : `${themeSubtle} hover:border-slate-500`
                }`}
              >
                <Gauge className="w-5 h-5 text-indigo-500" />
                <span className="text-[11px] font-bold mt-1">Velocidad</span>
                <span className="text-[9px] font-mono font-bold text-indigo-500 bg-indigo-500/10 px-1.5 py-0.2 rounded mt-0.5">
                  {speed.toFixed(speed % 1 === 0 ? 0 : 2)}x
                </span>
              </button>

              {/* 2. Calidad */}
              <button
                onClick={() => setActiveSheet('quality')}
                className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition active:scale-95 ${
                  activeSheet === 'quality'
                    ? 'border-sky-500 bg-sky-500/15 text-sky-500'
                    : `${themeSubtle} hover:border-slate-500`
                }`}
              >
                <Sliders className="w-5 h-5 text-sky-500" />
                <span className="text-[11px] font-bold mt-1">Calidad</span>
                <span className="text-[9px] font-mono font-bold text-sky-500 bg-sky-500/10 px-1.5 py-0.2 rounded mt-0.5">
                  {quality === 'custom' ? `${customHeight}p` : quality}
                </span>
              </button>

              {/* 3. Cortes */}
              <button
                onClick={() => setActiveSheet('cuts')}
                className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition active:scale-95 ${
                  activeSheet === 'cuts'
                    ? 'border-emerald-500 bg-emerald-500/15 text-emerald-500'
                    : `${themeSubtle} hover:border-slate-500`
                }`}
              >
                <Scissors className="w-5 h-5 text-emerald-500" />
                <span className="text-[11px] font-bold mt-1">Cortes</span>
                <span className="text-[9px] font-mono font-bold text-emerald-500 bg-emerald-500/10 px-1.5 py-0.2 rounded mt-0.5">
                  {effectiveCutSeconds}s
                </span>
              </button>
            </div>

            {/* Android Navigation Bar Pill */}
            <div className="pt-3">
              <div className="w-28 h-1 bg-slate-500/30 rounded-full mx-auto" />
            </div>
          </div>

          {/* ========================================================
              MODALES / BOTTOM SHEETS DESLIZABLES (DE ABAJO HACIA ARRIBA)
              ======================================================== */}
          {/* Modal 1: Velocidad */}
          <SpeedBottomSheet
            isOpen={activeSheet === 'speed'}
            onClose={() => setActiveSheet(null)}
            speed={speed}
            onSpeedChange={(val) => updatePref('speed', val)}
            muteAudio={muteAudio}
            onMuteChange={(val) => updatePref('muteAudio', val)}
            originalDuration={selectedVideo.duration}
            isDark={isDark}
          />

          {/* Modal 2: Calidad */}
          <QualityBottomSheet
            isOpen={activeSheet === 'quality'}
            onClose={() => setActiveSheet(null)}
            resolution={quality}
            onResolutionChange={(val) => updatePref('quality', val)}
            customHeight={customHeight}
            onCustomHeightChange={(val) => updatePref('customHeight', val)}
            originalWidth={selectedVideo.width}
            originalHeight={selectedVideo.height}
            isDark={isDark}
          />

          {/* Modal 3: Cortes */}
          <CutsBottomSheet
            isOpen={activeSheet === 'cuts'}
            onClose={() => setActiveSheet(null)}
            cutPreset={cutPreset}
            onCutPresetChange={(val) => updatePref('cutPreset', val)}
            customSeconds={customCutSeconds}
            onCustomSecondsChange={(val) => updatePref('customCutSeconds', val)}
            effectiveCutSeconds={effectiveCutSeconds}
            segments={segments}
            totalEffectiveDuration={estimatedTotalDuration}
            isDark={isDark}
          />
        </div>
      )}

      {/* Export Progress Modal */}
      <ProcessingProgressSheet
        progressState={exportState}
        onCancel={handleCancelExport}
      />

      {/* Result Summary Modal (con Compartir clips ordenados) */}
      <ResultSummaryModal
        isOpen={isSummaryOpen}
        onClose={() => setIsSummaryOpen(false)}
        segments={exportState.segments}
        baseVideoName={selectedVideo?.name || 'video'}
      />
    </div>
  );
};
