package com.cuttedvideo.app.domain.transformer

import android.content.Context
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.cuttedvideo.app.data.model.OutputResolution
import com.cuttedvideo.app.data.model.PlaybackSpeed
import com.cuttedvideo.app.data.model.SegmentPlan
import com.cuttedvideo.app.data.model.VideoMetadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class VideoTransformerEngine(private val context: Context) {

    private var currentTransformer: Transformer? = null

    /**
     * Procesa un segmento individual utilizando Media3 Transformer.
     * Aplica recorte exacto de tiempo, factor de velocidad personalizado,
     * opción de silenciar audio (mute) y escala de resolución/altura personalizada.
     */
    suspend fun exportSegment(
        sourceMetadata: VideoMetadata,
        segment: SegmentPlan,
        speedMultiplier: Float = 1.0f,
        resolution: OutputResolution,
        customHeight: Int = 1080,
        muteAudio: Boolean = false,
        tempOutputFile: File,
        onProgress: (Float) -> Unit
    ) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { continuation ->
            // 1. Configuración de recorte de medios (ClippingConfiguration)
            val clippingConfig = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(segment.startMs)
                .setEndPositionMs(segment.endMs)
                .setStartsAtKeyFrame(false)
                .build()

            val mediaItem = MediaItem.Builder()
                .setUri(sourceMetadata.uri)
                .setClippingConfiguration(clippingConfig)
                .build()

            // 2. Efectos de video (Escala, Resolución y Velocidad)
            val videoEffects = mutableListOf<Effect>()
            if (resolution == OutputResolution.CUSTOM) {
                videoEffects.add(Presentation.createForHeight(customHeight))
            } else if (resolution != OutputResolution.ORIGINAL) {
                val maxDim = resolution.maxDimension
                val targetHeight = if (sourceMetadata.isPortrait) {
                    maxDim
                } else {
                    (maxDim * sourceMetadata.height) / sourceMetadata.width
                }
                videoEffects.add(Presentation.createForHeight(targetHeight))
            }

            // Aplicar velocidad al video para sincronización perfecta
            if (speedMultiplier != 1.0f) {
                videoEffects.add(SpeedChangeEffect(speedMultiplier))
            }

            // 3. Procesamiento de audio para velocidad con Sonic (o silenciado)
            val audioProcessors = mutableListOf<androidx.media3.common.audio.AudioProcessor>()
            if (!muteAudio && speedMultiplier != 1.0f) {
                val sonic = SonicAudioProcessor().apply {
                    setSpeed(speedMultiplier)
                    setPitch(1.0f) // Conserva el tono natural sin distorsión de voz
                }
                audioProcessors.add(sonic)
            }

            // 4. Construcción de EditedMediaItem con efectos y opción de mute
            val effects = Effects(audioProcessors, videoEffects)
            val editedMediaItem = EditedMediaItem.Builder(mediaItem)
                .setEffects(effects)
                .setRemoveAudio(muteAudio) // Silencia completamente si se solicitó
                .build()

            // 5. Construir Transformer con listener compatible con Media3 1.3+
            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        currentTransformer = null
                        if (continuation.isActive) {
                            continuation.resume(Unit)
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        currentTransformer = null
                        if (continuation.isActive) {
                            continuation.resumeWithException(exportException)
                        }
                    }
                })
                .build()

            currentTransformer = transformer

            // Manejo de cancelación coroutine segura
            continuation.invokeOnCancellation {
                transformer.cancel()
                currentTransformer = null
                if (tempOutputFile.exists()) {
                    tempOutputFile.delete()
                }
            }

            // Iniciar transformación
            transformer.start(editedMediaItem, tempOutputFile.absolutePath)
        }
    }

    /**
     * Monitorea el progreso del Transformer activo mediante sondeo continuo.
     */
    suspend fun pollProgress(onProgress: (Float) -> Unit) = withContext(Dispatchers.Default) {
        val progressHolder = ProgressHolder()
        while (currentCoroutineContext().isActive && currentTransformer != null) {
            val transformer = currentTransformer ?: break
            val state = withContext(Dispatchers.Main) {
                transformer.getProgress(progressHolder)
            }
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                onProgress(progressHolder.progress / 100f)
            }
            delay(150)
        }
    }

    fun cancelCurrent() {
        currentTransformer?.cancel()
        currentTransformer = null
    }
}
