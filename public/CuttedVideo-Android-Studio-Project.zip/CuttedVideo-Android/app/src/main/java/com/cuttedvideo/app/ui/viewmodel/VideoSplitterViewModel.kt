package com.cuttedvideo.app.ui.viewmodel

import android.app.Application
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cuttedvideo.app.data.model.ExportState
import com.cuttedvideo.app.data.model.OutputResolution
import com.cuttedvideo.app.data.model.PlaybackSpeed
import com.cuttedvideo.app.data.model.SegmentPlan
import com.cuttedvideo.app.data.model.SplitProfile
import com.cuttedvideo.app.data.model.VideoMetadata
import com.cuttedvideo.app.data.repository.ProfilesRepository
import com.cuttedvideo.app.domain.mediastore.MediaStoreExporter
import com.cuttedvideo.app.domain.transformer.VideoTransformerEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.ceil

class VideoSplitterViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val prefs = application.getSharedPreferences("cuttedvideo_user_config", Context.MODE_PRIVATE)
    private val transformerEngine = VideoTransformerEngine(context)
    private val mediaStoreExporter = MediaStoreExporter(context)
    val profilesRepository = ProfilesRepository()

    private val _themeMode = MutableStateFlow(prefs.getString("theme_mode", "auto") ?: "auto")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _selectedVideo = MutableStateFlow<VideoMetadata?>(null)
    val selectedVideo: StateFlow<VideoMetadata?> = _selectedVideo.asStateFlow()

    private val _selectedSpeedMultiplier = MutableStateFlow(prefs.getFloat("speed_multiplier", 1.0f))
    val selectedSpeedMultiplier: StateFlow<Float> = _selectedSpeedMultiplier.asStateFlow()

    // Compatibilidad para evitar errores en llamadas existentes
    val selectedSpeed: StateFlow<PlaybackSpeed> = MutableStateFlow(PlaybackSpeed.SPEED_1_0X).asStateFlow()

    private val _muteAudio = MutableStateFlow(prefs.getBoolean("mute_audio", false))
    val muteAudio: StateFlow<Boolean> = _muteAudio.asStateFlow()

    private val _selectedResolution = MutableStateFlow(
        runCatching {
            OutputResolution.valueOf(prefs.getString("selected_resolution", "ORIGINAL") ?: "ORIGINAL")
        }.getOrDefault(OutputResolution.ORIGINAL)
    )
    val selectedResolution: StateFlow<OutputResolution> = _selectedResolution.asStateFlow()

    private val _customHeight = MutableStateFlow(prefs.getInt("custom_height", 1080))
    val customHeight: StateFlow<Int> = _customHeight.asStateFlow()

    private val _selectedProfile = MutableStateFlow<SplitProfile?>(null)
    val selectedProfile: StateFlow<SplitProfile?> = _selectedProfile.asStateFlow()

    private val _customDurationSeconds = MutableStateFlow(prefs.getInt("custom_duration_seconds", 30))
    val customDurationSeconds: StateFlow<Int> = _customDurationSeconds.asStateFlow()

    private val _exportState = MutableStateFlow<ExportState>(ExportState.Idle)
    val exportState: StateFlow<ExportState> = _exportState.asStateFlow()

    private var exportJob: Job? = null

    init {
        viewModelScope.launch {
            profilesRepository.profiles.collect { list ->
                if (_selectedProfile.value == null && list.isNotEmpty()) {
                    _selectedProfile.value = list.first()
                }
            }
        }
    }

    /**
     * Procesa la URI recibida desde Android Photo Picker.
     */
    fun onVideoPicked(uri: Uri) {
        viewModelScope.launch {
            try {
                val metadata = extractMetadataFromUri(uri)
                _selectedVideo.value = metadata
            } catch (e: Exception) {
                _exportState.value = ExportState.Error("No se pudieron leer los metadatos del video: ${e.localizedMessage}")
            }
        }
    }

    fun clearVideo() {
        _selectedVideo.value = null
    }

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode).apply()
    }

    fun setSpeedMultiplier(multiplier: Float) {
        val rounded = (multiplier * 100).toInt() / 100f
        _selectedSpeedMultiplier.value = rounded
        prefs.edit().putFloat("speed_multiplier", rounded).apply()
    }

    fun setSpeed(speed: PlaybackSpeed) {
        setSpeedMultiplier(speed.multiplier)
    }

    fun setMuteAudio(mute: Boolean) {
        _muteAudio.value = mute
        prefs.edit().putBoolean("mute_audio", mute).apply()
    }

    fun setResolution(res: OutputResolution) {
        _selectedResolution.value = res
        prefs.edit().putString("selected_resolution", res.name).apply()
    }

    fun setCustomHeight(height: Int) {
        _customHeight.value = height
        prefs.edit().putInt("custom_height", height).apply()
    }

    fun selectProfile(profile: SplitProfile) {
        _selectedProfile.value = profile
        if (profile.id == "custom") {
            _customDurationSeconds.value = profile.maxDurationSeconds
        }
    }

    fun setCustomDuration(seconds: Int) {
        val clamped = seconds.coerceAtLeast(1)
        _customDurationSeconds.value = clamped
        prefs.edit().putInt("custom_duration_seconds", clamped).apply()
    }

    /**
     * Calcula la lista de segmentos considerando la duración estimada tras aplicar la velocidad.
     */
    fun calculateSegmentPlans(): List<SegmentPlan> {
        val video = _selectedVideo.value ?: return emptyList()
        val speedMultiplier = _selectedSpeedMultiplier.value
        val maxDurationSec = if (_selectedProfile.value?.id == "custom") {
            _customDurationSeconds.value
        } else {
            _selectedProfile.value?.maxDurationSeconds ?: 30
        }

        val sourceChunkSec = maxDurationSec * speedMultiplier
        val totalSourceSec = video.durationSeconds
        val numSegments = ceil(totalSourceSec / sourceChunkSec).toInt()

        val plans = mutableListOf<SegmentPlan>()
        val baseCleanName = video.name.substringBeforeLast(".").replace("[^a-zA-Z0-9]".toRegex(), "_")

        for (i in 0 until numSegments) {
            val startSourceMs = (i * sourceChunkSec * 1000).toLong()
            val endSourceMs = minOf(video.durationMs, ((i + 1) * sourceChunkSec * 1000).toLong())
            val actualSourceSec = (endSourceMs - startSourceMs) / 1000f
            val outputDuration = actualSourceSec / speedMultiplier

            plans.add(
                SegmentPlan(
                    index = i + 1,
                    fileName = "${baseCleanName}_${String.format("%03d", i + 1)}.mp4",
                    startMs = startSourceMs,
                    endMs = endSourceMs,
                    outputDurationSeconds = outputDuration
                )
            )
        }
        return plans
    }

    /**
     * Inicia el procesamiento secuencial con Media3 Transformer y guardado en MediaStore.
     */
    fun startExport() {
        val video = _selectedVideo.value ?: return
        val segments = calculateSegmentPlans()
        if (segments.isEmpty()) return

        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            _exportState.value = ExportState.Exporting(
                currentSegmentIndex = 1,
                totalSegments = segments.size,
                currentSegmentProgress = 0f,
                overallProgress = 0f
            )

            var savedCount = 0
            val total = segments.size
            val savedClipsList = mutableListOf<com.cuttedvideo.app.data.model.ExportedClip>()

            for (seg in segments) {
                val tempFile = File(context.cacheDir, "temp_clip_${seg.index}.mp4")
                if (tempFile.exists()) tempFile.delete()

                try {
                    // Iniciar sondeo de progreso de Transformer
                    val progressJob = launch {
                        transformerEngine.pollProgress { segProg ->
                            val overall = ((savedCount + segProg) / total)
                            _exportState.update {
                                ExportState.Exporting(
                                    currentSegmentIndex = seg.index,
                                    totalSegments = total,
                                    currentSegmentProgress = segProg,
                                    overallProgress = overall
                                )
                            }
                        }
                    }

                    // Ejecución real de Media3 Transformer con velocidad, calidad y mute
                    transformerEngine.exportSegment(
                        sourceMetadata = video,
                        segment = seg,
                        speedMultiplier = _selectedSpeedMultiplier.value,
                        resolution = _selectedResolution.value,
                        customHeight = _customHeight.value,
                        muteAudio = _muteAudio.value,
                        tempOutputFile = tempFile,
                        onProgress = {}
                    )
                    progressJob.cancel()

                    // Guardar en MediaStore (Movies/VideoSplit) sin sobrescribir
                    val uniqueName = mediaStoreExporter.generateUniqueFilename(
                        baseName = video.name.substringBeforeLast("."),
                        index = seg.index
                    )
                    val itemUri = mediaStoreExporter.saveToMediaStore(tempFile, uniqueName)
                    savedClipsList.add(
                        com.cuttedvideo.app.data.model.ExportedClip(
                            uri = itemUri,
                            fileName = uniqueName,
                            index = seg.index
                        )
                    )

                    tempFile.delete()
                    savedCount++
                } catch (e: Exception) {
                    if (tempFile.exists()) tempFile.delete()
                    if (e is kotlinx.coroutines.CancellationException) {
                        _exportState.value = ExportState.Cancelled
                        return@launch
                    }
                    _exportState.value = ExportState.Error("Error exportando clip ${seg.index}: ${e.localizedMessage}")
                    return@launch
                }
            }

            _exportState.value = ExportState.Completed(
                totalSavedClips = savedCount,
                savedClips = savedClipsList
            )
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        transformerEngine.cancelCurrent()
        _exportState.value = ExportState.Cancelled
    }

    fun resetExportState() {
        _exportState.value = ExportState.Idle
    }

    private fun extractMetadataFromUri(uri: Uri): VideoMetadata {
        val resolver = context.contentResolver
        var name = "video_${System.currentTimeMillis()}.mp4"
        var size = 0L

        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
            }
        }

        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(context, uri)

        val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
        val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
        val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
        val mimeType = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "video/mp4"

        val durationMs = durationStr?.toLongOrNull() ?: 0L
        val width = widthStr?.toIntOrNull() ?: 1080
        val height = heightStr?.toIntOrNull() ?: 1920

        retriever.release()

        return VideoMetadata(
            uri = uri,
            name = name,
            durationMs = durationMs,
            width = width,
            height = height,
            sizeBytes = size,
            mimeType = mimeType
        )
    }
}
