package com.cuttedvideo.app.data.model

import android.net.Uri

data class VideoMetadata(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val mimeType: String
) {
    val durationSeconds: Float
        get() = durationMs / 1000f

    val isPortrait: Boolean
        get() = height > width
}

enum class PlaybackSpeed(val multiplier: Float, val label: String) {
    SPEED_0_5X(0.5f, "0,5x"),
    SPEED_0_75X(0.75f, "0,75x"),
    SPEED_1_0X(1.0f, "1x"),
    SPEED_1_25X(1.25f, "1,25x"),
    SPEED_1_5X(1.5f, "1,5x"),
    SPEED_2_0X(2.0f, "2x")
}

enum class OutputResolution(val label: String, val maxDimension: Int) {
    ORIGINAL("Original", 0),
    RES_1080P("1080p (FHD)", 1920),
    RES_720P("720p (HD)", 1280),
    RES_480P("480p (SD)", 854),
    CUSTOM("Personalizada", 0)
}

data class SplitProfile(
    val id: String,
    val name: String,
    val platform: String,
    val maxDurationSeconds: Int,
    val isEditable: Boolean = true
)

data class SegmentPlan(
    val index: Int,
    val fileName: String,
    val startMs: Long,
    val endMs: Long,
    val outputDurationSeconds: Float
)

data class ExportedClip(
    val uri: Uri,
    val fileName: String,
    val index: Int
)

sealed interface ExportState {
    data object Idle : ExportState
    data class Exporting(
        val currentSegmentIndex: Int,
        val totalSegments: Int,
        val currentSegmentProgress: Float,
        val overallProgress: Float
    ) : ExportState
    data class Completed(
        val totalSavedClips: Int,
        val destinationFolder: String = "Movies/VideoSplit",
        val savedClips: List<ExportedClip> = emptyList()
    ) : ExportState
    data class Error(val message: String) : ExportState
    data object Cancelled : ExportState
}
