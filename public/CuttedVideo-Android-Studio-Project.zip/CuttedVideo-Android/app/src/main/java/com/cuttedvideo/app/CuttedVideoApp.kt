package com.cuttedvideo.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder

class CuttedVideoApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                // Habilita extracción de fotogramas de video nativamente con Coil
                add(VideoFrameDecoder.Factory())
            }
            .crossfade(true)
            .build()
    }
}
