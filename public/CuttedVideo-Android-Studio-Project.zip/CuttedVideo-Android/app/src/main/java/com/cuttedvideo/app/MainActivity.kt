package com.cuttedvideo.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cuttedvideo.app.data.model.ExportState
import com.cuttedvideo.app.data.model.ExportedClip
import com.cuttedvideo.app.ui.screens.HomeScreen
import com.cuttedvideo.app.ui.viewmodel.VideoSplitterViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VideoSplitterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val useDark = when (themeMode) {
                "claro" -> false
                "oscuro" -> true
                else -> systemDark
            }

            MaterialTheme(
                colorScheme = if (useDark) darkColorScheme() else lightColorScheme()
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val exportState by viewModel.exportState.collectAsState()

                    HomeScreen(
                        viewModel = viewModel
                    )

                    if (exportState !is ExportState.Idle) {
                        ProcessingDialog(
                            state = exportState,
                            onCancel = { viewModel.cancelExport() },
                            onDismiss = { viewModel.resetExportState() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProcessingDialog(
    state: ExportState,
    onCancel: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    when (state) {
        is ExportState.Exporting -> {
            val progressPercent = (state.overallProgress * 100).toInt()
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Dividiendo y exportando clips...") },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Clip ${state.currentSegmentIndex} de ${state.totalSegments}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                "$progressPercent%",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        LinearProgressIndicator(
                            progress = { state.overallProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                        )
                        Text(
                            "Guardando en Movies/VideoSplit",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = onCancel) {
                        Text("Cancelar")
                    }
                }
            )
        }
        is ExportState.Completed -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text("¡Clips listos en tu galería!") },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Se guardaron ${state.totalSavedClips} clips en Movies/VideoSplit.")

                        // Botón principal para compartir todos los clips juntos y en estricto orden
                        Button(
                            onClick = {
                                val sortedClips = state.savedClips.sortedBy { it.index }
                                val uris = ArrayList(sortedClips.map { it.uri })
                                val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                    type = "video/mp4"
                                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                                    putExtra(Intent.EXTRA_SUBJECT, "Clips ordenados (1 al ${state.totalSavedClips})")
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "Clips ordenados del 1 al ${state.totalSavedClips} listos para publicar (CuttedVideo)"
                                    )
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Compartir clips en orden correlativo"))
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Compartir todos los clips en orden (1 al ${state.totalSavedClips})")
                        }

                        // Lista para compartir clip por clip individualmente
                        if (state.savedClips.isNotEmpty()) {
                            Text(
                                "O comparte clip por clip en orden:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 180.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(state.savedClips) { clip ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = MaterialTheme.shapes.small,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                                .fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                "Parte ${clip.index}: ${clip.fileName}",
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.weight(1f)
                                            )
                                            IconButton(
                                                onClick = {
                                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                                        type = "video/mp4"
                                                        putExtra(Intent.EXTRA_STREAM, clip.uri)
                                                        putExtra(
                                                            Intent.EXTRA_TEXT,
                                                            "Parte ${clip.index} de ${state.totalSavedClips}"
                                                        )
                                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                    }
                                                    context.startActivity(
                                                        Intent.createChooser(intent, "Compartir parte ${clip.index} de ${state.totalSavedClips}")
                                                    )
                                                }
                                            ) {
                                                Icon(
                                                    Icons.Default.Share,
                                                    contentDescription = "Compartir parte ${clip.index}",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = onDismiss) {
                        Text("Listo")
                    }
                }
            )
        }
        is ExportState.Error -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text("Error al procesar") },
                text = { Text(state.message) },
                confirmButton = {
                    Button(onClick = onDismiss) {
                        Text("Cerrar")
                    }
                }
            )
        }
        is ExportState.Cancelled -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text("Exportación cancelada") },
                text = { Text("El proceso se detuvo y no se guardaron archivos incompletos.") },
                confirmButton = {
                    Button(onClick = onDismiss) {
                        Text("Aceptar")
                    }
                }
            )
        }
        else -> Unit
    }
}
