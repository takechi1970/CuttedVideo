package com.cuttedvideo.app.data.repository

import com.cuttedvideo.app.data.model.SplitProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ProfilesRepository {

    private val _profiles = MutableStateFlow(
        listOf(
            SplitProfile("wa_30", "WhatsApp Estados (30s)", "WhatsApp", 30),
            SplitProfile("wa_60", "WhatsApp Estados (60s)", "WhatsApp", 60),
            SplitProfile("ig_reels_90", "Instagram Reels (90s)", "Instagram", 90),
            SplitProfile("ig_stories_60", "Instagram Historias (60s)", "Instagram", 60),
            SplitProfile("tiktok_60", "TikTok (60s)", "TikTok", 60),
            SplitProfile("custom", "Personalizado", "Personalizado", 15)
        )
    )
    val profiles: StateFlow<List<SplitProfile>> = _profiles.asStateFlow()

    fun updateProfile(id: String, newDurationSeconds: Int) {
        _profiles.value = _profiles.value.map { profile ->
            if (profile.id == id) {
                profile.copy(maxDurationSeconds = newDurationSeconds.coerceAtLeast(1))
            } else {
                profile
            }
        }
    }

    fun addCustomProfile(name: String, maxDurationSeconds: Int) {
        val newProfile = SplitProfile(
            id = "custom_${System.currentTimeMillis()}",
            name = name,
            platform = "Personalizado",
            maxDurationSeconds = maxDurationSeconds.coerceAtLeast(1)
        )
        _profiles.value = _profiles.value + newProfile
    }

    fun deleteProfile(id: String) {
        _profiles.value = _profiles.value.filter { it.id != id }
    }
}
