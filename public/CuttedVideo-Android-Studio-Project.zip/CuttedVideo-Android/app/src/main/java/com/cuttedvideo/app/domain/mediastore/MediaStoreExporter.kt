package com.cuttedvideo.app.domain.mediastore

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

class MediaStoreExporter(private val context: Context) {

    companion object {
        const val SUBDIRECTORY = "Movies/VideoSplit"
    }

    /**
     * Genera un nombre de archivo secuencial único que no sobrescriba archivos existentes.
     * Ejemplo: clip_001.mp4, clip_002.mp4, etc.
     */
    suspend fun generateUniqueFilename(baseName: String, index: Int): String = withContext(Dispatchers.IO) {
        val formattedIndex = String.format("%03d", index)
        var candidateName = "${baseName}_${formattedIndex}.mp4"
        var counter = 1

        while (fileExistsInMediaStore(candidateName)) {
            candidateName = "${baseName}_${formattedIndex}_${counter}.mp4"
            counter++
        }
        candidateName
    }

    /**
     * Copia un archivo MP4 temporal exportado por Media3 a la galería mediante MediaStore.
     * Utiliza IS_PENDING para evitar que la galería muestre archivos incompletos.
     */
    suspend fun saveToMediaStore(tempFile: File, displayName: String): Uri = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver

        val contentValues = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoSplit")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collection, contentValues)
            ?: throw IllegalStateException("No se pudo crear entrada en MediaStore para: $displayName")

        try {
            resolver.openOutputStream(itemUri)?.use { outputStream ->
                FileInputStream(tempFile).use { inputStream ->
                    inputStream.copyTo(outputStream)
                }
            } ?: throw IllegalStateException("No se pudo abrir OutputStream para $itemUri")

            // Marcar como listo en la galería
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(itemUri, contentValues, null, null)
            }

            itemUri
        } catch (e: Exception) {
            // Limpieza en caso de fallo para no dejar archivos corruptos
            resolver.delete(itemUri, null, null)
            throw e
        }
    }

    private fun fileExistsInMediaStore(displayName: String): Boolean {
        val projection = arrayOf(MediaStore.Video.Media._ID)
        val selection = "${MediaStore.Video.Media.DISPLAY_NAME} = ?"
        val selectionArgs = arrayOf(displayName)

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        context.contentResolver.query(collection, projection, selection, selectionArgs, null)?.use { cursor ->
            return cursor.count > 0
        }
        return false
    }
}
