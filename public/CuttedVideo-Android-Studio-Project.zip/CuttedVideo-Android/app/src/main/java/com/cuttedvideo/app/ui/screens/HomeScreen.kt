package com.cuttedvideo.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.cuttedvideo.app.data.model.ExportState
import com.cuttedvideo.app.data.model.OutputResolution
import com.cuttedvideo.app.data.model.PlaybackSpeed
import com.cuttedvideo.app.data.model.VideoMetadata
import com.cuttedvideo.app.ui.viewmodel.VideoSplitterViewModel
import java.util.Locale
import kotlin.math.roundToInt

private enum class ActiveBottomSheet {
    NONE,
    SPEED,
    QUALITY,
    CUTS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: VideoSplitterViewModel
) {
    val selectedVideo by viewModel.selectedVideo.collectAsState()
    val speedMultiplier by viewModel.selectedSpeedMultiplier.collectAsState()
    val muteAudio by viewModel.muteAudio.collectAsState()
    val resolution by viewModel.selectedResolution.collectAsState()
    val customHeight by viewModel.customHeight.collectAsState()
    val customDuration by viewModel.customDurationSeconds.collectAsState()
    val exportState by viewModel.exportState.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    var activeSheet by remember { mutableStateOf(ActiveBottomSheet.NONE) }
    var isPlayingPreview by remember { mutableStateOf(false) }

    // Launcher de Android Photo Picker nativo (sin permisos invasivos)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.onVideoPicked(it) }
    }

    val plans = remember(selectedVideo, speedMultiplier, customDuration) {
        viewModel.calculateSegmentPlans()
    }

    if (selectedVideo == null) {
        // ==========================================
        // PANTALLA 1: PRINCIPAL / SUBIR ARCHIVO (Sin Scroll)
        // ==========================================
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.ContentCut,
                                        contentDescription = "Logo CuttedVideo",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Text(
                                "CuttedVideo",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    actions = {
                        // Selector superior derecho: "Auto", "Claro", "Oscuro"
                        Row(
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(2.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            listOf("auto" to "Auto", "claro" to "Claro", "oscuro" to "Oscuro").forEach { (key, label) ->
                                val selected = themeMode == key
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { viewModel.setThemeMode(key) }
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            modifier = Modifier.size(76.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.VideoLibrary,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Comienza seleccionando un video",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                "Divide tus videos automáticamente en fragmentos continuos con audio 100% sincronizado.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }

                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.Upload, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Subir / Seleccionar Video", fontWeight = FontWeight.SemiBold)
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    Icons.Default.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    "Formatos compatibles: MP4, MOV, MKV · Cortes exactos para WhatsApp (30s), Historias (60s) y Reels (90s).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    } else {
        // ==========================================
        // PANTALLA 2: EDITOR CON VIDEO SIEMPRE EN PANTALLA
        // ==========================================
        val video = selectedVideo!!
        val context = LocalContext.current
        val effectiveDuration = (video.durationSeconds / speedMultiplier)

        Scaffold(
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { viewModel.clearVideo() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Cambiar video")
                        }
                    },
                    title = {
                        Column {
                            Text(
                                text = video.name,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val clipDurationLabel = when (customDuration) {
                                30 -> "30s"
                                60 -> "60s"
                                90 -> "90s"
                                else -> "${customDuration}s"
                            }
                            Text(
                                text = "${plans.size} clips de $clipDurationLabel",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    actions = {
                        // Botón superior derecho: "Cortar y Procesar"
                        Button(
                            onClick = { viewModel.startExport() },
                            enabled = exportState is ExportState.Idle,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Cortar y Procesar", fontWeight = FontWeight.Bold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                // Menú inferior con 3 iconos: Velocidad, Calidad y Cortes
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    NavigationBarItem(
                        selected = activeSheet == ActiveBottomSheet.SPEED,
                        onClick = { activeSheet = ActiveBottomSheet.SPEED },
                        icon = { Icon(Icons.Default.Speed, contentDescription = "Velocidad") },
                        label = { Text("Velocidad (${String.format(Locale.US, "%.1f", speedMultiplier)}x)") }
                    )
                    NavigationBarItem(
                        selected = activeSheet == ActiveBottomSheet.QUALITY,
                        onClick = { activeSheet = ActiveBottomSheet.QUALITY },
                        icon = { Icon(Icons.Default.HighQuality, contentDescription = "Calidad") },
                        label = { Text("Calidad") }
                    )
                    NavigationBarItem(
                        selected = activeSheet == ActiveBottomSheet.CUTS,
                        onClick = { activeSheet = ActiveBottomSheet.CUTS },
                        icon = { Icon(Icons.Default.ContentCut, contentDescription = "Cortes") },
                        label = { Text("Cortes (${customDuration}s)") }
                    )
                }
            }
        ) { innerPadding ->
            // Área de contenido sin scroll (Video siempre visible)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Reproductor / Previsualización de video con controles
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(video.uri)
                            .videoFrameMillis(1000)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Previsualización del video",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Control Play / Pause en el centro
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.65f),
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .clickable { isPlayingPreview = !isPlayingPreview }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (isPlayingPreview) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlayingPreview) "Pausar" else "Reproducir",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    // Insignia flotante con resolución y duración
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${video.width}x${video.height}",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text("•", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                            Text(
                                "${String.format(Locale.US, "%.1f", video.durationSeconds)}s orig.",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall
                            )
                            if (speedMultiplier != 1.0f) {
                                Text("•", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                Text(
                                    "${String.format(Locale.US, "%.1f", effectiveDuration)}s a ${String.format(Locale.US, "%.2f", speedMultiplier)}x",
                                    color = MaterialTheme.colorScheme.primary,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Tarjeta resumen limpia con datos clave
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Clips", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${plans.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.height(28.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Corte Máx.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${customDuration}s", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.height(28.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Audio", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(if (muteAudio) "Muteado" else "Activo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.height(28.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Calidad", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(if (resolution == OutputResolution.CUSTOM) "${customHeight}p" else resolution.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // ==========================================
        // HOJAS MODALES INFERIORES (MODAL BOTTOM SHEETS)
        // ==========================================

        // 1. MODAL DE VELOCIDAD
        if (activeSheet == ActiveBottomSheet.SPEED) {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActiveBottomSheet.NONE },
                sheetState = rememberModalBottomSheetState()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Velocidad de Reproducción", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { activeSheet = ActiveBottomSheet.NONE }) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar")
                        }
                    }

                    // Botones rápidos de velocidad habituales
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { s ->
                            val isSelected = (speedMultiplier == s)
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setSpeedMultiplier(s) },
                                label = { Text("${s}x") }
                            )
                        }
                    }

                    // Barra Slider de 5 en 5 para velocidad personalizada
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Velocidad Personalizada (pasos de 0.05):", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "${String.format(Locale.US, "%.2f", speedMultiplier)}x",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = speedMultiplier,
                            onValueChange = { newVal ->
                                val stepped = (newVal * 20).roundToInt() / 20f
                                viewModel.setSpeedMultiplier(stepped)
                            },
                            valueRange = 0.25f..2.50f,
                            steps = 44
                        )
                    }

                    // Información comparativa: Duración original vs Duración resultante
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Duración original: ${String.format(Locale.US, "%.1f", video.durationSeconds)} segundos", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "Duración con velocidad seleccionada: ${String.format(Locale.US, "%.1f", effectiveDuration)} segundos",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Checkbox para mutear el video (Default: NO)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { viewModel.setMuteAudio(!muteAudio) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = muteAudio,
                            onCheckedChange = { viewModel.setMuteAudio(it) }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Silenciar audio (Mute)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Text("Elimina la pista de sonido de los clips exportados (Default: No)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // 2. MODAL DE CALIDAD
        if (activeSheet == ActiveBottomSheet.QUALITY) {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActiveBottomSheet.NONE },
                sheetState = rememberModalBottomSheetState()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Calidad y Resolución", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { activeSheet = ActiveBottomSheet.NONE }) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar")
                        }
                    }

                    // 4 botones: 3 calidades habituales y 1 personalizada
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            OutputResolution.ORIGINAL to "Original",
                            OutputResolution.RES_1080P to "1080p (FHD)",
                            OutputResolution.RES_720P to "720p (HD)",
                            OutputResolution.CUSTOM to "Personalizada"
                        ).forEach { (res, label) ->
                            FilterChip(
                                selected = resolution == res,
                                onClick = { viewModel.setResolution(res) },
                                label = { Text(label) }
                            )
                        }
                    }

                    // Si se seleccionó personalizada, mostrar slider
                    if (resolution == OutputResolution.CUSTOM) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Resolución vertical deseada:", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "${customHeight}p",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = customHeight.toFloat(),
                                onValueChange = { viewModel.setCustomHeight(((it / 60).roundToInt() * 60).coerceIn(360, 2160)) },
                                valueRange = 360f..2160f,
                                steps = 29
                            )
                        }
                    }

                    // Información útil de la sección de Calidad
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "Resolución actual del video: ${video.width} x ${video.height} píxeles",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Consejo: Usar Original preserva la nitidez exacta sin reescalado innecesario. Reducir la resolución a 720p acelerará notablemente el tiempo de exportación en dispositivos con procesadores ajustados.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 3. MODAL DE CORTES
        if (activeSheet == ActiveBottomSheet.CUTS) {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActiveBottomSheet.NONE },
                sheetState = rememberModalBottomSheetState()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Duración de los Cortes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { activeSheet = ActiveBottomSheet.NONE }) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar")
                        }
                    }

                    // 4 botones: 30s, 60s, 90s y personalizada
                    val isPreset = (customDuration == 30 || customDuration == 60 || customDuration == 90)
                    var isCustomSelected by remember { mutableStateOf(!isPreset) }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(30 to "30 seg", 60 to "60 seg", 90 to "90 seg").forEach { (sec, label) ->
                            FilterChip(
                                selected = (!isCustomSelected && customDuration == sec),
                                onClick = {
                                    isCustomSelected = false
                                    viewModel.setCustomDuration(sec)
                                },
                                label = { Text(label) }
                            )
                        }
                        FilterChip(
                            selected = isCustomSelected,
                            onClick = { isCustomSelected = true },
                            label = { Text("Personalizada") }
                        )
                    }

                    // Slider si se toca personalizada
                    if (isCustomSelected) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Duración máxima por clip:", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "${customDuration} seg",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = customDuration.toFloat(),
                                onValueChange = { viewModel.setCustomDuration(((it / 5).roundToInt() * 5).coerceIn(5, 180)) },
                                valueRange = 5f..180f,
                                steps = 34
                            )
                        }
                    }

                    // Información útil de la sección de Cortes
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "Resultado estimado: ${plans.size} clips de máximo ${customDuration}s cada uno.",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "30s es ideal para estados de WhatsApp. 60s para Historias de Instagram. 90s para Reels y TikTok.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
