# CuttedVideo - Aplicación Android Nativa

CuttedVideo es una aplicación nativa para Android construida con **Kotlin**, **Jetpack Compose**, **Material 3** y **AndroidX Media3 Transformer**.

## Requisitos
- **Android Studio Ladybug (2024.2+)** o Koala
- **JDK 17**
- Dispositivo o Emulador con Android 8.0+ (API 26+)

## Características Principales
1. **AndroidX Media3 Transformer**:
   - Recorte preciso de fotogramas mediante `ClippingConfiguration`.
   - Modificación de velocidad de reproducción (0,5x a 2x) usando `SonicAudioProcessor` para conservar el tono de voz natural.
   - Ajuste de resolución (1080p, 720p, 480p) con `Presentation` y `ScaleAndRotateTransformation`.
2. **Android Photo Picker**:
   - Selección segura y moderna de videos sin solicitar permisos invasivos de almacenamiento en Android 13+.
3. **MediaStore**:
   - Guardado directo en la carpeta pública `Movies/VideoSplit`.
   - Control con `IS_PENDING` para evitar archivos corruptos en la galería.
   - Nombres secuenciales (`clip_001.mp4`, etc.) con verificación para no sobrescribir archivos.
4. **Perfiles Dinámicos**:
   - Perfiles configurables para WhatsApp Status (30s / 60s), Instagram Reels (90s), Historias (60s), TikTok y duración personalizada.

## Cómo compilar y ejecutar
1. Descarga el archivo ZIP del proyecto desde el visor web.
2. Descomprime la carpeta y ábrela en **Android Studio**.
3. Deja que Gradle sincronice las dependencias (`androidx.media3:media3-transformer:1.3.1`).
4. Conecta tu teléfono Android o inicia un emulador y haz clic en **Run 'app'** (`Shift + F10`).
